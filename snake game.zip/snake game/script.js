const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const box = 20; 
let snake = [{ x: 10 * box, y: 10 * box }];
let food = { x: randomBox(), y: randomBox() };
let direction = "RIGHT";
let gameSpeed = 200;
let game;

// Generate a random grid position
function randomBox() {
    return Math.floor(Math.random() * 20) * box;
}

// Detect keyboard input
document.addEventListener("keydown", changeDirection);

function changeDirection(event) {
    const key = event.keyCode;
    if (key === 37 && direction !== "RIGHT") direction = "LEFT";
    else if (key === 38 && direction !== "DOWN") direction = "UP";
    else if (key === 39 && direction !== "LEFT") direction = "RIGHT";
    else if (key === 40 && direction !== "UP") direction = "DOWN";
}

// Mobile Controls
function changeDirectionByButton(newDirection) {
    if (newDirection === "LEFT" && direction !== "RIGHT") direction = "LEFT";
    else if (newDirection === "UP" && direction !== "DOWN") direction = "UP";
    else if (newDirection === "RIGHT" && direction !== "LEFT") direction = "RIGHT";
    else if (newDirection === "DOWN" && direction !== "UP") direction = "DOWN";
}

function draw() {
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw food
    ctx.fillStyle = "red";
    ctx.fillRect(food.x, food.y, box, box);

    // Draw snake
    for (let i = 0; i < snake.length; i++) {
        ctx.fillStyle = i === 0 ? "lime" : "green";
        ctx.fillRect(snake[i].x, snake[i].y, box, box);
        ctx.strokeStyle = "black";
        ctx.strokeRect(snake[i].x, snake[i].y, box, box);
    }

    // Move snake
    let snakeX = snake[0].x;
    let snakeY = snake[0].y;

    if (direction === "LEFT") snakeX -= box;
    if (direction === "UP") snakeY -= box;
    if (direction === "RIGHT") snakeX += box;
    if (direction === "DOWN") snakeY += box;

    // Check collision with food
    if (snakeX === food.x && snakeY === food.y) {
        food = { x: randomBox(), y: randomBox() };
    } else {
        snake.pop();
    }

    // Check collision with walls or itself
    if (
        snakeX < 0 || snakeX >= canvas.width ||
        snakeY < 0 || snakeY >= canvas.height ||
        collision({ x: snakeX, y: snakeY }, snake)
    ) {
        clearInterval(game);
        alert("Game Over! Tap to Restart.");
        location.reload(); // Reload the game on mobile
    }

    // Create new head
    let newHead = { x: snakeX, y: snakeY };
    snake.unshift(newHead);
}

// Collision Detection
function collision(head, array) {
    for (let i = 1; i < array.length; i++) {
        if (head.x === array[i].x && head.y === array[i].y) return true;
    }
    return false;
}

// Start Game
game = setInterval(draw, 200);
